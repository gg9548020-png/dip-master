# DIP MASTER Android Build Package

This archive is arranged at repository root. Extract its contents directly into the
root of an authorized GitHub repository (the files `settings.gradle` and `app/`
must be at the repository root).

## Build APK
1. Push/commit all files to the repository's `main` or `master` branch.
2. Open GitHub → Actions → **Build DIP MASTER debug APK**.
3. Select **Run workflow**.
4. Wait for a successful run, then download the `DIP-MASTER-debug-apk` artifact.
5. Install the APK on an Android test device and verify it before production use.

The workflow also runs on pushes to `main`/`master`.

## Important limits
- This is a local/offline demo; generated period and BIG/SMALL values are simulated.
- It is not an official BDG WIN live feed, prediction, or verified API integration.
- Telegram bot code is a separate starter and requires a real bot token and six numeric
  admin IDs configured securely in the hosting environment. Do not put secrets in source.
- No APK is included in this source package because no successful Android build has yet
  been run.
