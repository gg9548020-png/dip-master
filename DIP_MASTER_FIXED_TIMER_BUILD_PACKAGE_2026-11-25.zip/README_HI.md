# DIP MASTER Android — Build Package v1.2.2

यह प्रोजेक्ट DIP MASTER board को Android WebView app में पैक करता है।

## APK build
1. ZIP extract करें।
2. ZIP के अंदर की सभी files/folders सीधे अधिकृत GitHub repository के root में upload करें। Root में `settings.gradle` होना चाहिए।
3. GitHub में **Actions** खोलें।
4. **Build DIP MASTER debug APK** workflow चुनें और **Run workflow** दबाएँ।
5. सफल run के बाद **Artifacts** में `DIP-MASTER-debug-apk` डाउनलोड करें।
6. पहले एक test phone पर install करके जाँचें।

## Cloud build requirements
- Java 17
- Gradle 8.7
- Android SDK platform 35
- Android build-tools 35.0.0

## शामिल सामग्री
Android WebView wrapper, offline board HTML, Telegram polling starter, GitHub Actions APK build workflow, status और QA notes।

## सीमाएँ
यह ZIP compiled APK नहीं है। इस workspace में Android SDK/Gradle उपलब्ध न होने और linked GitHub account में accessible repository न मिलने के कारण APK build अभी execute नहीं हुआ।
Board अभी offline demo है। Telegram bot starter minimal है; production Telegram/Pusher/webhook/live backend और छह-device acceptance testing बाकी हैं।
