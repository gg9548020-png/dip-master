Cleaned package: repository-root layout; Python cache files removed. See README_BUILD_HI_EN.md.
